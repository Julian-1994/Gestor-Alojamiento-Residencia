package com.Gestor_Alojamiento.Config;

public class BatchConfig {

}
