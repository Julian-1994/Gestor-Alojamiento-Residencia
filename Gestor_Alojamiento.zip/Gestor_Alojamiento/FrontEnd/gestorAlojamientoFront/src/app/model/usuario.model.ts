export interface Usuario {
  id: number;
  nombreUsuario: string;
  contrasenya: string;
  rol: string;
  email: string;
}