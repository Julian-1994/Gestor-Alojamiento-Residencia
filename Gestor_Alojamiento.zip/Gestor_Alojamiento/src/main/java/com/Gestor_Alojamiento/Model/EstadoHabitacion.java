package com.Gestor_Alojamiento.Model;

public enum EstadoHabitacion {
DISPONIBLE,
OCUPADA,
}
