package com.Gestor_Alojamiento.Gestor_Alojamiento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestorAlojamientoApplicationTests {

	@Test
	void contextLoads() {
	}

}
