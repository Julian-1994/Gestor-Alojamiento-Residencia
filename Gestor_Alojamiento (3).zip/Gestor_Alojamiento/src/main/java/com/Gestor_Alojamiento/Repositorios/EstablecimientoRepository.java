package com.Gestor_Alojamiento.Repositorios;
import org.springframework.data.jpa.repository.JpaRepository;
import com.Gestor_Alojamiento.Model.Establecimiento;



public interface EstablecimientoRepository extends JpaRepository<Establecimiento, Integer> {

}