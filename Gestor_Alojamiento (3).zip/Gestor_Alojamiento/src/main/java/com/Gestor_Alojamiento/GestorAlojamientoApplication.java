package com.Gestor_Alojamiento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.Gestor_Alojamiento")
public class GestorAlojamientoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestorAlojamientoApplication.class, args);
	}

}
